
#include <stdio.h>							// including Libraries
#include <math.h>

void main(void)
{
 double half_life, age, rem_c, lost_c;					// Defining Variables

 printf("Percentage of carbon defficiency (0-100%)? ");			
 scanf("%lf", &lost_c);						// Taking User Input

 half_life = 5730.0;
 rem_c = 1.0 - (lost_c/100.0);
 age = -(half_life / log10(2.0)) * log10(rem_c);				// Calculating The age.

 printf("The object is %lf years old.\n", age);				// Printing the outputs.

 getch();
 clrscr();
}