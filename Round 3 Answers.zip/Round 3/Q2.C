#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>										// Including Libraries
#include<dos.h>



int smile (int,int);										// defining functions
int sad(int,int);
int speechless(int,int);
int ashamed(int,int);
int amazed(int,int);
int cry(int,int);



void main()
{
   int emotion;
   int gd = DETECT, gm, area, temp1, temp2;							// defining variables 
   void *p;

   initgraph(&gd,&gm,"C:\\turboc3\\bgi");		// "C:\\turboc3\\bgi" this directory may change.		// Initializing graphics system and funtions from the mentioned directory


   while (emotion != 0)
   { 	

          int left = 425, top = 95;									// initializing markers to cut / collect printed emoji from the screen

          cleardevice();									// Clearing the console screen
          gotoxy(1,1);										// Moving the cursor to (1,1) location

          printf(" Choose Your Emotion : \n 1 For Happyness \n 2 For Sadness \n 3 For Speechless \n 4 For Crying \n 5 For Amazed \n 6 For Ashamed \n Anything Else to Exit. \n");		// Menu

          emotion = getch() - '0';									// Getting the user input from getch() buffer.

          switch (emotion)									// Genereting the emoji and storing it in "p" depending on the user input.
	{
	     case 1: p = malloc(smile(left,top)); break;
	     case 2: p = malloc(sad(left,top)); break;
	     case 3: p = malloc(speechless(left,top)); break;
	     case 4: p = malloc(cry(left,top)); break;
	     case 5: p = malloc(amazed(left,top)); break;
	     case 6: p = malloc(ashamed(left,top)); break;
	     default: emotion = 0; continue;
	}


          while(!kbhit())									// This loop will run and print the emoji at random positions until user cooses another option.
              {
	      temp1 = 1 + (rand() % (588 - 50+ 1)) + 50;						// generating new x coordinate.
	      temp2 = 1 + (rand() % (380 - 150+ 1)) + 150;						// generating new y coordinate.

          	     getimage(left, top, left + 50, top + 50, p);						// collecting the emoji from the old position
           	     putimage(left, top, p, XOR_PUT);
           	     putimage(temp1 , temp2, p, XOR_PUT);						// drawing the emoji at new coordinates

           	     delay(1000);									// delay between every transition is 1 second

           	     left = temp1;									// storing new values
           	     top = temp2;

	}
                
        free(p);										// deallocating the memory of old emoji

    }
   
   printf("Thanks For Using This !!!!!");
   getch();
   closegraph();
}



int smile(int left,int top)									// function to draw smile emoji
{	

   setcolor(YELLOW);									// face boundary
   circle(450,120,25);

   setfillstyle(SOLID_FILL,YELLOW);								// face colour
   floodfill(450,120,YELLOW);

   setcolor(BLACK);
   setfillstyle(SOLID_FILL,BLACK);								// eyes
   fillellipse(444,110,2,6);
   fillellipse(456,110,2,6);

   ellipse(450,120,205,335,20,9);								// mouth
   ellipse(450,120,205,335,20,10);
   ellipse(450,120,205,335,20,11);

   return  imagesize(left, top, left + 50, top + 50);							// returning the imagesize
}



int sad(int left,int top)									// function to draw sad emoji
{
   setcolor(YELLOW);									// face boundary
   circle(450,120,25);

   setfillstyle(SOLID_FILL,YELLOW);								// face colour
   floodfill(450,120,YELLOW);

   setcolor(BLACK);										// eyes
   setfillstyle(SOLID_FILL,BLACK);
   fillellipse(444,110,2,6);
   fillellipse(456,110,2,6);

   ellipse(450,132,360,185,20,9);
   ellipse(450,132,360,185,20,11);								// mouth
   ellipse(450,132,360,185,20,10);

   return  imagesize(left, top, left + 50, top + 50);							// returning the imagesize
}


int speechless(int left,int top)									// function for speechless emoji
{
   setcolor(YELLOW);									// face boundary
   circle(450,120,25);

   setfillstyle(SOLID_FILL,YELLOW);								// face colour
   floodfill(450,120,YELLOW);

   setcolor(BLACK);
   setfillstyle(SOLID_FILL,BLACK);								// eyes
   fillellipse(444,110,2,6);
   fillellipse(456,110,2,6);

   return  imagesize(left, top, left + 50, top + 50);							// returning the image size
}


int cry(int left,int top)									// function for cry emoji
{

   setcolor(YELLOW);									// face boundary
   circle(450,120,25);

   setfillstyle(SOLID_FILL,YELLOW);								// face colour
   floodfill(450,120,YELLOW);

   setcolor(BLACK);										// eyes
   setfillstyle(SOLID_FILL,BLACK);
   fillellipse(444,110,2,6);
   fillellipse(456,110,2,6);

   setcolor(BLUE);
   setfillstyle(SOLID_FILL,CYAN);								// tears
   fillellipse(456,122,3,7);

   setcolor(BLACK);										// mouth
   ellipse(450,124,205,335,20,9);
   ellipse(450,124,205,335,20,10);
   ellipse(450,124,205,335,20,11);

   return  imagesize(left, top, left + 50, top + 50);							// returning the image size
}


int amazed(int left,int top)									// function for amazed emoji
{
   setcolor(YELLOW);									// face boundary
   circle(450,120,25);

   setfillstyle(SOLID_FILL,YELLOW);								// face colour
   floodfill(450,120,YELLOW);

   setcolor(BLACK);
   setfillstyle(SOLID_FILL,BLACK);								// eyes
   fillellipse(444,110,2,6);
   fillellipse(456,110,2,6);

   ellipse(450,132,10,340,10,9);
   ellipse(450,132,10,340,10,11);								// mouth
   ellipse(450,132,10,340,10,10);

   setfillstyle(SOLID_FILL,WHITE);								// mouth colour
   fillellipse(450,132,10,9);

   return  imagesize(left, top, left + 50, top + 50);							// returning the image size
}


int ashamed(int left,int top)									// function for ashamed emoji
{
   setcolor(YELLOW);									// face boundary
   circle(450,120,25);

   setfillstyle(SOLID_FILL,YELLOW);								// face colour
   floodfill(450,120,YELLOW);

   setcolor(BLACK);
   setfillstyle(SOLID_FILL,BLACK);
   fillellipse(444,112,2,6);									// eyes
   fillellipse(456,112,2,6);


   line(432,128,468,128);
   line(432,129,468,129);									// mouth
   line(432,130,468,130);

   return  imagesize(left, top, left + 50, top + 50);							// returning the image size
}

